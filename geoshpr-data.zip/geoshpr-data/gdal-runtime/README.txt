Files obtained from Windows vcpkg installation of GDAL located at
/vcpkg/installed/x64-windows/share/gdal

I believe the version of GDAL these came from is 2.4.1-8 (that's the version I currently have installed).

I also had to add proj.dll which came from /vcpkg/installed/x64-windows/bin/